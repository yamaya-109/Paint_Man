package com.example.paintapi.paintmatcher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaintmatcherApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaintmatcherApplication.class, args);
	}

}
